import requests
import json

# inspired by https://www.vrealize.it/2021/07/07/set-deployment-name-to-vm-name/ which works for new deployments
# for onboarded vms:
#    needed to modify this script to use a different inputs - 
#       1 - Deployments for onboarding have different data payload. need to take the deployment ID and submit 2nd 
#           API call to get VM name
#       2 - subscription for different event - 

def handler(context, inputs):

    refreshtoken = context.getSecret(inputs["RefreshToken"])
    vrahost = "vra8.cybersylum.com"
    
    # Request Bearer Token
    requesturl = "https://" + vrahost + "/iaas/api/login"
    headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
    }

    requestbody = {
        'refreshToken': refreshtoken
    }   

    response = requests.post(url=requesturl, data=json.dumps(requestbody),headers=headers,verify=False)
    responseJson = response.json()
    bearer = responseJson["token"]
  
    headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + bearer
    }
    
    #use deploymentId to get VM name
    print("API call to get resources in onboarding deployment")
    deploymentId = inputs["__metadata"]["targetId"]
    requesturl = "https://" + vrahost + "/deployment/api/deployments/" + deploymentId + "/resources?$filter=type eq 'Cloud.vSphere.Machine'"
    response = requests.get(url=requesturl, data=json.dumps(requestbody),headers=headers,verify=False)
    responseJson = response.json()
    vmName = responseJson["content"][0]["name"]

    #Update the name of the deployment
    requestbody = {
        'name': vmName
    }
    
    requesturl = "https://" + vrahost + "/deployment/api/deployments/" + deploymentId
    print("API call to update deployment name")
    response = requests.patch(url=requesturl, data=json.dumps(requestbody),headers=headers,verify=False)